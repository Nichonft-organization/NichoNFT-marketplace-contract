require('dotenv').config();

const GogglesNFT = artifacts.require("GogglesNFT");

const FEE_ADDRESS = `${process.env.FEE_ADDRESS}`;

module.exports = function (deployer) {
  deployer.deploy(GogglesNFT, FEE_ADDRESS);
};
